# TCR Repertoire Polyclonality AI Framework
## Supplementary Source Code

**Manuscript:** T-Cell Receptor Repertoire Polyclonality Suppresses Mature T-Cell Lymphoma
Through Homeostatic Clonal Competition: A Seven-Module Artificial Intelligence Framework

**Authors:** Ashok Kumar¹, Mudasar Latif Memon*², Marvi Shaikh³  
**Affiliation:** CRAIMS, Department of Information Technology, UMS, Tando Muhammad Khan, Sindh, Pakistan  
**Correspondence:** m.memon@ums.edu.pk

---

## Framework Overview

Seven independently deployable AI/ML modules targeting TCR diversity-based
lymphoma risk assessment and gene therapy safety surveillance:

| Module | File | Algorithm | Key Output |
|--------|------|-----------|------------|
| M1 | `module1_tcr_diversity/` | DeepTCR-inspired + Shannon Entropy MLP | Polyclonality Index; Lymphoma Risk Score |
| M2 | `module2_rl_abm/` | Stochastic ODE + RL-ABM | Tipping-point PI; Clone escape probability |
| M3 | `module3_gnn_niche/` | Graph-based TCR-MHC affinity | Niche affinity score per clone |
| M4 | `module4_xgboost/` | XGBoost + SHAP | Transformation probability; Feature attribution |
| M5 | `module5_cnn_integration/` | 1D-CNN + Fisher CIS detection | Integration site risk score; CIS flags |
| M6 | `module6_histopath/` | Patch-based ViT-inspired classifier | ALCL vs. Lymphoblastic vs. Reactive |
| M7 | `module7_ensemble/` | Stacking ensemble + SHAP | RED/AMBER/GREEN Safety Index |

---

## Installation

```bash
pip install -r requirements.txt
```

## Quick Start

```bash
# Run full pipeline (all 7 modules, simulated data)
python main_pipeline.py

# Run individual modules
python module1_tcr_diversity/polyclonality_scorer.py
python module2_rl_abm/clonal_competition_sim.py
python module4_xgboost/transformation_classifier.py
python module7_ensemble/safety_index.py
```

## Dependencies
- Python >= 3.9
- numpy, scipy, scikit-learn, xgboost, shap, matplotlib, seaborn

## Citation
If you use this code, please cite:
> Kumar A, Memon ML, Shaikh M. T-Cell Receptor Repertoire Polyclonality Suppresses
> Mature T-Cell Lymphoma Through Homeostatic Clonal Competition: A Seven-Module
> Artificial Intelligence Framework. [Journal], 2025.

## License
Academic use only. All rights reserved by the authors.

"""
module1_tcr_diversity/polyclonality_scorer.py
=============================================
Module 1: Deep Learning-Based TCR Repertoire Diversity Scoring
and Lymphoma Risk Classification.

Implements:
    - Polyclonality Index (PI) computation via normalized Shannon entropy
    - Rank-abundance curve analysis (Gini, Hill numbers)
    - MLP-based lymphoma risk classifier (DeepTCR-inspired)
    - RED / AMBER / GREEN repertoire zone classification
    - Full evaluation with AUROC, F1, MCC

Mathematical formulation (Eq. 1, Manuscript Section 4.1.1):
    PI = H / log₂(N_clones)
       = [-∑ p_i · log₂(p_i)] / log₂(N_clones)

    Risk score R = σ(w^T · f(CDR3α, CDR3β, V/J) + b)
                 = 1 / (1 + e^(-z))       (Eq. 2)

Reference:
    Newrzela S, et al. Leukemia. 2012;26(12):2456-2464.
    Sidhom JW, et al. Nat Commun. 2021;12:1605.  [DeepTCR]

Authors:
    Ashok Kumar¹, Mudasar Latif Memon*²
    CRAIMS, UMS, Tando Muhammad Khan, Sindh, Pakistan
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

from scipy.stats import mannwhitneyu, ks_2samp
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import (
    roc_auc_score, f1_score, matthews_corrcoef,
    roc_curve, classification_report, confusion_matrix
)
from sklearn.pipeline import Pipeline

from utils.data_simulation import (
    simulate_tcr_dataset, simulate_tcr_repertoire,
    compute_polyclonality_index, _shannon_entropy, _gini
)

# ---------------------------------------------------------------------------
# Safety zone thresholds (calibrated to RL-ABM tipping point, Module 2)
# ---------------------------------------------------------------------------
PI_RED_THRESHOLD   = 0.30   # below → RED (high lymphoma risk)
PI_GREEN_THRESHOLD = 0.80   # above → GREEN (safe)


# ---------------------------------------------------------------------------
# Core: Diversity Metrics
# ---------------------------------------------------------------------------
def compute_diversity_metrics(frequencies: np.ndarray) -> dict:
    """Compute a comprehensive set of repertoire diversity metrics.

    Args:
        frequencies: Clone frequency array. Will be normalized internally.

    Returns:
        Dictionary containing:
            pi          – Polyclonality Index (normalized Shannon H)
            shannon_H   – Raw Shannon entropy (bits)
            gini        – Gini coefficient [0, 1]
            top_clone   – Frequency of the most dominant clone
            hill_q1     – Hill number order 1 (exp of Shannon H)
            hill_q2     – Hill number order 2 (inverse Simpson)
            clonality   – 1 − PI (complementary measure)
            zone        – 'RED' | 'AMBER' | 'GREEN'
    """
    freq = np.asarray(frequencies, dtype=np.float64)
    freq = freq / freq.sum()                  # normalize

    n      = len(freq)
    H      = _shannon_entropy(freq)
    H_max  = np.log2(n) if n > 1 else 1.0
    pi     = H / H_max if H_max > 0 else 0.0

    # Hill numbers
    hill_q1 = float(np.exp(H / np.log2(np.e)))       # exp(H_nats)
    freq_sq = np.sum(freq ** 2)
    hill_q2 = float(1.0 / freq_sq) if freq_sq > 0 else n

    zone = (
        "RED"   if pi < PI_RED_THRESHOLD   else
        "GREEN" if pi > PI_GREEN_THRESHOLD else
        "AMBER"
    )

    return {
        "pi":        round(pi, 4),
        "shannon_H": round(H, 4),
        "gini":      round(_gini(freq), 4),
        "top_clone": round(float(freq.max()), 5),
        "hill_q1":   round(hill_q1, 3),
        "hill_q2":   round(hill_q2, 3),
        "clonality": round(1.0 - pi, 4),
        "zone":      zone,
        "n_clones":  n,
    }


def classify_zone(pi: float) -> str:
    """Classify a PI value into RED / AMBER / GREEN safety zone.

    Args:
        pi: Polyclonality Index value ∈ [0, 1].

    Returns:
        Zone string: 'RED', 'AMBER', or 'GREEN'.
    """
    if pi < PI_RED_THRESHOLD:
        return "RED"
    elif pi > PI_GREEN_THRESHOLD:
        return "GREEN"
    return "AMBER"


# ---------------------------------------------------------------------------
# CDR3 Sequence Feature Encoder
# ---------------------------------------------------------------------------
def encode_cdr3(sequences: np.ndarray, max_len: int = 18) -> np.ndarray:
    """Encode CDR3 amino acid sequences into numeric feature vectors.

    Uses physicochemical property encoding (charge, hydrophobicity, volume)
    inspired by the BLOSUM-based approach in DeepTCR [Sidhom et al., 2021].

    Each amino acid is encoded as a 3-dimensional vector:
        [normalized_charge, hydrophobicity, normalized_volume]

    The full CDR3 sequence is represented as:
        [mean_charge, mean_hydrophob, mean_volume, len_norm,
         charge_range, hydrophob_range]

    Args:
        sequences: Array of CDR3 amino acid strings.
        max_len:   Maximum CDR3 length for normalization.

    Returns:
        Feature matrix of shape (len(sequences), 6).
    """
    # Physicochemical property tables
    charge = {
        "R": 1.0, "K": 0.8, "H": 0.1, "D": -0.8, "E": -1.0,
        "A": 0, "C": 0, "F": 0, "G": 0, "I": 0, "L": 0,
        "M": 0, "N": 0, "P": 0, "Q": 0, "S": 0, "T": 0,
        "V": 0, "W": 0, "Y": 0,
    }
    hydrophob = {
        "I": 1.0, "L": 0.92, "V": 0.74, "F": 0.88, "M": 0.64,
        "W": 0.81, "A": 0.61, "C": 0.68, "Y": 0.49, "T": 0.35,
        "H": 0.18, "G": 0.16, "S": 0.20, "Q": 0.10, "N": 0.08,
        "P": 0.12, "R": -0.2, "K": -0.22, "D": -0.4, "E": -0.42,
    }
    volume = {
        "G": 0.04, "A": 0.09, "S": 0.12, "P": 0.14, "V": 0.15,
        "T": 0.16, "C": 0.16, "I": 0.20, "L": 0.20, "N": 0.20,
        "D": 0.19, "Q": 0.24, "K": 0.24, "E": 0.23, "M": 0.22,
        "H": 0.25, "F": 0.27, "R": 0.28, "Y": 0.30, "W": 0.34,
    }

    features = []
    for seq in sequences:
        seq = seq.upper()[:max_len]
        if len(seq) == 0:
            features.append([0.0] * 6)
            continue
        ch  = [charge.get(aa, 0)     for aa in seq]
        hyd = [hydrophob.get(aa, 0)  for aa in seq]
        vol = [volume.get(aa, 0.15)  for aa in seq]

        features.append([
            np.mean(ch),
            np.mean(hyd),
            np.mean(vol),
            len(seq) / max_len,
            max(ch) - min(ch),
            max(hyd) - min(hyd),
        ])
    return np.array(features, dtype=np.float32)


# ---------------------------------------------------------------------------
# Module 1: Lymphoma Risk Classifier (MLP)
# ---------------------------------------------------------------------------
class TCRLymphomaRiskClassifier:
    """MLP-based lymphoma risk classifier operating on TCR repertoire features.

    Implements the classification head described in Manuscript Section 4.1.1
    (Eq. 2). Input features include polyclonality index, Gini coefficient,
    top-clone dominance, V-gene diversity, and clone count.

    Attributes:
        pipeline   : sklearn Pipeline (scaler + MLP).
        threshold  : Decision threshold for lymphoma-positive call.
        fitted     : Whether the model has been trained.
        cv_auroc   : Cross-validated AUROC.
        cv_f1      : Cross-validated F1-score.
    """

    def __init__(self, threshold: float = 0.50):
        self.threshold = threshold
        self.fitted    = False
        self.cv_auroc  = None
        self.cv_f1     = None
        self.pipeline  = Pipeline([
            ("scaler", StandardScaler()),
            ("mlp", MLPClassifier(
                hidden_layer_sizes=(64, 32, 16),
                activation="relu",
                solver="adam",
                alpha=1e-3,
                max_iter=500,
                random_state=42,
                early_stopping=True,
                validation_fraction=0.15,
            ))
        ])

    def fit(self, X: np.ndarray, y: np.ndarray) -> "TCRLymphomaRiskClassifier":
        """Train the classifier with cross-validated performance estimation.

        Args:
            X: Feature matrix (n_samples × 5).
            y: Binary lymphoma labels (0=healthy, 1=lymphoma).

        Returns:
            self
        """
        self.pipeline.fit(X, y)
        self.fitted = True

        # Cross-validated performance
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        y_prob_cv = cross_val_predict(
            self.pipeline, X, y, cv=cv, method="predict_proba"
        )[:, 1]
        self.cv_auroc = roc_auc_score(y, y_prob_cv)
        self.cv_f1    = f1_score(y, (y_prob_cv >= self.threshold).astype(int))
        self.cv_mcc   = matthews_corrcoef(y, (y_prob_cv >= self.threshold).astype(int))
        self._y_prob_cv = y_prob_cv
        self._y = y
        return self

    def predict_risk(self, X: np.ndarray) -> np.ndarray:
        """Predict lymphoma risk scores for new repertoire samples.

        Args:
            X: Feature matrix (n_samples × 5).

        Returns:
            Risk scores ∈ [0, 1] (shape [n_samples]).
        """
        assert self.fitted, "Classifier must be fitted first (call .fit)."
        return self.pipeline.predict_proba(X)[:, 1]

    def predict_zone(self, pi_values: np.ndarray) -> List[str]:
        """Predict RED / AMBER / GREEN zone from PI values directly.

        Args:
            pi_values: Array of Polyclonality Index values.

        Returns:
            List of zone strings.
        """
        return [classify_zone(pi) for pi in pi_values]

    def performance_summary(self) -> dict:
        """Return performance summary from cross-validation."""
        if not self.fitted:
            return {}
        return {
            "5-fold CV AUROC":    round(self.cv_auroc, 4),
            "5-fold CV F1":       round(self.cv_f1, 4),
            "5-fold CV MCC":      round(self.cv_mcc, 4),
            "Decision threshold": self.threshold,
        }


# ---------------------------------------------------------------------------
# Visualisation
# ---------------------------------------------------------------------------
def plot_module1_results(
    classifier: TCRLymphomaRiskClassifier,
    pi_array: np.ndarray,
    y_true: np.ndarray,
    save_path: str = "outputs/M1_results.png"
) -> None:
    """Generate the three-panel Module 1 results figure.

    Panels:
        A – PI distribution by class with safety zones
        B – ROC curve from 5-fold cross-validation
        C – Sigmoid risk score vs PI with experimental landmarks

    Args:
        classifier: A fitted TCRLymphomaRiskClassifier.
        pi_array:   Polyclonality index array (n_samples).
        y_true:     Binary lymphoma labels.
        save_path:  Output PNG file path.
    """
    fig = plt.figure(figsize=(16, 5), facecolor="white")
    gs  = gridspec.GridSpec(1, 3, wspace=0.38)

    # --- Panel A: PI distribution ---
    ax1 = fig.add_subplot(gs[0])
    pi_healthy  = pi_array[y_true == 0]
    pi_lymphoma = pi_array[y_true == 1]

    ax1.hist(pi_lymphoma, bins=25, alpha=0.72, color="#C62828",
             label="Lymphoma (y=1)", density=True, edgecolor="white")
    ax1.hist(pi_healthy,  bins=25, alpha=0.72, color="#2E7D32",
             label="Healthy (y=0)",  density=True, edgecolor="white")
    ax1.axvline(PI_RED_THRESHOLD,   color="#1565C0", lw=2, ls="--",
                label=f"RED threshold (PI={PI_RED_THRESHOLD})")
    ax1.axvline(PI_GREEN_THRESHOLD, color="#00695C", lw=2, ls=":",
                label=f"GREEN lower bound (PI={PI_GREEN_THRESHOLD})")
    ax1.axvspan(0, PI_RED_THRESHOLD, alpha=0.07, color="red")
    ax1.axvspan(PI_RED_THRESHOLD, PI_GREEN_THRESHOLD, alpha=0.05, color="orange")
    ax1.axvspan(PI_GREEN_THRESHOLD, 1.0, alpha=0.07, color="green")

    y_lim = ax1.get_ylim()[1]
    ax1.text(0.15, y_lim * 0.92, "HIGH\nRISK", ha="center", fontsize=8,
             fontweight="bold", color="#C62828")
    ax1.text(0.55, y_lim * 0.92, "AMBER",     ha="center", fontsize=8,
             fontweight="bold", color="#E65100")
    ax1.text(0.90, y_lim * 0.92, "SAFE",      ha="center", fontsize=8,
             fontweight="bold", color="#2E7D32")

    mw_stat, mw_p = mannwhitneyu(pi_lymphoma, pi_healthy, alternative="less")
    ax1.set_xlabel("Polyclonality Index (PI)", fontsize=11, fontweight="bold")
    ax1.set_ylabel("Density", fontsize=11, fontweight="bold")
    ax1.set_title(f"A.  PI Distribution by Outcome\n(Mann-Whitney p={mw_p:.2e})",
                  fontsize=10, fontweight="bold")
    ax1.legend(fontsize=7.5)
    ax1.set_xlim(0, 1)

    # --- Panel B: ROC Curve ---
    ax2 = fig.add_subplot(gs[1])
    y_prob = classifier._y_prob_cv
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    auroc = classifier.cv_auroc

    ax2.plot(fpr, tpr, color="#1565C0", lw=2.5,
             label=f"MLP Classifier (AUROC = {auroc:.3f})")
    ax2.fill_between(fpr, tpr, alpha=0.12, color="#1565C0")
    ax2.plot([0, 1], [0, 1], "k--", lw=1.2, alpha=0.5, label="Random (0.500)")
    ax2.set_xlabel("False Positive Rate", fontsize=11, fontweight="bold")
    ax2.set_ylabel("True Positive Rate", fontsize=11, fontweight="bold")
    ax2.set_title(f"B.  ROC Curve (5-Fold CV)\nAUROC = {auroc:.3f} | "
                  f"F1 = {classifier.cv_f1:.3f} | MCC = {classifier.cv_mcc:.3f}",
                  fontsize=10, fontweight="bold")
    ax2.legend(fontsize=9)
    ax2.set_xlim([0, 1]); ax2.set_ylim([0, 1.02])

    # --- Panel C: Sigmoid risk curve + experimental landmarks ---
    ax3 = fig.add_subplot(gs[2])
    pi_vals = np.linspace(0, 1, 300)
    risk_curve = 1.0 / (1.0 + np.exp(8 * (pi_vals - 0.45)))

    ax3.plot(pi_vals, risk_curve, color="#1565C0", lw=2.5,
             label="Predicted risk (sigmoid)")
    ax3.fill_between(pi_vals, risk_curve, alpha=0.12, color="#1565C0")

    # Experimental landmarks from Newrzela et al. [1]
    landmarks = [
        (PI_RED_THRESHOLD - 0.23, 0.98, "OT-I/NPM-ALK\n(100%)", "#C62828", "^"),
        (PI_RED_THRESHOLD - 0.23, 0.72, "OT-I/ΔTrkA\n(~70%)",   "#E65100", "s"),
        (PI_GREEN_THRESHOLD - 0.05, 0.08, "WT/NPM-ALK\n(33%)", "#2E7D32", "D"),
        (PI_GREEN_THRESHOLD + 0.05, 0.02, "WT polyclonal\n(0%)", "#1565C0", "o"),
    ]
    for px, py, lbl, col, mk in landmarks:
        ax3.scatter([px], [py], c=col, marker=mk, s=80, zorder=10,
                    edgecolors="white", linewidths=0.8)
        ax3.annotate(lbl, (px, py), textcoords="offset points",
                     xytext=(8, 4), fontsize=7, color=col, fontweight="bold")

    ax3.axhline(0.50, color="#C62828", lw=1.5, ls="--", alpha=0.6,
                label="Decision boundary (R=0.50)")
    ax3.axvline(PI_RED_THRESHOLD,   color="#1565C0", lw=1.2, ls=":", alpha=0.7)
    ax3.axvline(PI_GREEN_THRESHOLD, color="#00695C", lw=1.2, ls=":", alpha=0.7)
    ax3.set_xlabel("Polyclonality Index (PI)", fontsize=11, fontweight="bold")
    ax3.set_ylabel("Predicted Lymphoma Risk Score R", fontsize=11, fontweight="bold")
    ax3.set_title("C.  Risk Score vs. PI\nwith Experimental Landmarks [1]",
                  fontsize=10, fontweight="bold")
    ax3.legend(fontsize=8)
    ax3.set_xlim(0, 1); ax3.set_ylim(0, 1.05)

    fig.suptitle("Module 1: TCR Repertoire Diversity Scoring and Lymphoma Risk Classification",
                 fontsize=13, fontweight="bold", color="#1A237E", y=1.02)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.tight_layout()
    plt.savefig(save_path, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"[M1] Figure saved → {save_path}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def run_module1(verbose: bool = True) -> dict:
    """Run the complete Module 1 pipeline.

    Returns:
        Dictionary of performance metrics and diversity summaries.
    """
    print("\n" + "="*60)
    print("  MODULE 1: TCR Diversity Scoring & Lymphoma Risk Classifier")
    print("="*60)

    # 1. Simulate data
    X, y, pi = simulate_tcr_dataset(n_samples=400, seed=42)

    # 2. Diversity metrics for representative conditions
    _, freq_mono = simulate_tcr_repertoire(200, "monoclonal", seed=1)
    _, freq_poly = simulate_tcr_repertoire(200, "polyclonal", seed=2)
    _, freq_canc = simulate_tcr_repertoire(200, "cancer",     seed=3)

    metrics_mono = compute_diversity_metrics(freq_mono)
    metrics_poly = compute_diversity_metrics(freq_poly)
    metrics_canc = compute_diversity_metrics(freq_canc)

    if verbose:
        print("\n  Diversity Metrics by Condition:")
        print(f"    Monoclonal (OT-I/P14): PI={metrics_mono['pi']:.3f}  "
              f"Shannon H={metrics_mono['shannon_H']:.3f}  "
              f"Zone={metrics_mono['zone']}")
        print(f"    Cancer (MTCL patient): PI={metrics_canc['pi']:.3f}  "
              f"Shannon H={metrics_canc['shannon_H']:.3f}  "
              f"Zone={metrics_canc['zone']}")
        print(f"    Polyclonal (WT):        PI={metrics_poly['pi']:.3f}  "
              f"Shannon H={metrics_poly['shannon_H']:.3f}  "
              f"Zone={metrics_poly['zone']}")

    # 3. Train classifier
    clf = TCRLymphomaRiskClassifier(threshold=0.50)
    clf.fit(X, y)
    perf = clf.performance_summary()

    if verbose:
        print("\n  Classifier Performance (5-fold cross-validation):")
        for k, v in perf.items():
            print(f"    {k}: {v}")

    # 4. Classification report
    y_pred = (clf._y_prob_cv >= 0.50).astype(int)
    if verbose:
        print("\n  Classification Report:")
        print(classification_report(y, y_pred, target_names=["Healthy", "Lymphoma"]))

    # 5. Visualize
    plot_module1_results(
        clf, pi, y,
        save_path="outputs/M1_TCR_Diversity_Results.png"
    )

    return {
        "metrics_monoclonal": metrics_mono,
        "metrics_polyclonal": metrics_poly,
        "classifier_performance": perf,
    }


if __name__ == "__main__":
    from typing import List
    result = run_module1(verbose=True)

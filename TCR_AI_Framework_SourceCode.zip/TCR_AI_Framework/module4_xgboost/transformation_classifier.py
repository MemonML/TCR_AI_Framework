"""
module4_xgboost/transformation_classifier.py
=============================================
Module 4: Gradient-Boosted Classification of Oncogene-Specific
Transformation Susceptibility.

Implements the XGBoost classifier with SHAP-based feature attribution
described in Manuscript Section 4.4.

Objective function minimized (Eq. 5):
    L(θ) = ∑_i [y_i·log(ŷ_i) + (1-y_i)·log(1-ŷ_i)] + Ω(θ)

SHAP values (Shapley Additive Explanations):
    φ_i = ∑_{S⊆F∖{i}} [|S|!(|F|-|S|-1)!/|F|!] · [f_x(S∪{i}) - f_x(S)]

Input features:
    - Polyclonality Index (PI)           [from Module 1]
    - Niche Affinity Variance σ²(A_i)   [from Module 3]
    - Oncogene Strength (0/0.5/1.0)
    - Transduction Efficiency
    - T-cell Phenotype (naive/memory)
    - Integration Site Risk              [from Module 5]

Reference:
    Chen T, Guestrin C. XGBoost: a scalable tree boosting system. KDD 2016.
    Lundberg SM, Lee SI. A unified approach to interpreting model predictions.
    NeurIPS 2017;30:4765-4774.

Authors:
    Ashok Kumar¹, Mudasar Latif Memon*²
    CRAIMS, UMS, Tando Muhammad Khan, Sindh, Pakistan
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import warnings
warnings.filterwarnings("ignore")

import xgboost as xgb
import shap
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import (
    roc_auc_score, f1_score, matthews_corrcoef,
    roc_curve, classification_report, average_precision_score,
    ConfusionMatrixDisplay, confusion_matrix
)
from sklearn.calibration import calibration_curve

from utils.data_simulation import simulate_transformation_dataset


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------
class TransformationSusceptibilityClassifier:
    """XGBoost classifier for oncogene-induced transformation risk.

    Predicts the probability that a given T-cell preparation will undergo
    malignant transformation, given pre-transplant measurable features.

    Attributes:
        model:          Trained XGBoost classifier.
        feat_names:     List of feature names.
        shap_explainer: SHAP TreeExplainer for feature attribution.
        cv_metrics:     Cross-validated performance metrics.
    """

    def __init__(self, n_estimators: int = 300, max_depth: int = 4,
                 learning_rate: float = 0.05, seed: int = 42):
        self.model = xgb.XGBClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            subsample=0.8,
            colsample_bytree=0.8,
            use_label_encoder=False,
            eval_metric="logloss",
            random_state=seed,
            verbosity=0,
        )
        self.feat_names    = None
        self.shap_explainer = None
        self.cv_metrics    = {}
        self._X_train      = None
        self._shap_values  = None

    def fit(self, X: np.ndarray, y: np.ndarray,
            feat_names: list = None) -> "TransformationSusceptibilityClassifier":
        """Train the classifier and compute cross-validated metrics.

        Args:
            X:          Feature matrix (n_samples × n_features).
            y:          Binary transformation labels.
            feat_names: Feature name list for SHAP plots.

        Returns:
            self
        """
        self.feat_names = feat_names or [f"feature_{i}" for i in range(X.shape[1])]
        self.model.fit(X, y)
        self._X_train = X

        # SHAP explanations
        self.shap_explainer = shap.TreeExplainer(self.model)
        self._shap_values   = self.shap_explainer.shap_values(X)

        # Cross-validated metrics
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        y_prob_cv = cross_val_predict(
            self.model, X, y, cv=cv, method="predict_proba"
        )[:, 1]
        y_pred_cv = (y_prob_cv >= 0.50).astype(int)

        self.cv_metrics = {
            "AUROC":    round(roc_auc_score(y, y_prob_cv), 4),
            "F1":       round(f1_score(y, y_pred_cv), 4),
            "MCC":      round(matthews_corrcoef(y, y_pred_cv), 4),
            "AUPRC":    round(average_precision_score(y, y_prob_cv), 4),
        }
        self._y_prob_cv = y_prob_cv
        self._y         = y
        return self

    def predict_risk(self, X: np.ndarray) -> np.ndarray:
        """Predict transformation probability for new samples.

        Args:
            X: Feature matrix.

        Returns:
            Transformation probability scores ∈ [0, 1].
        """
        return self.model.predict_proba(X)[:, 1]

    def get_global_shap(self) -> dict:
        """Return global mean |SHAP| importance per feature.

        Returns:
            Dict mapping feature name → mean absolute SHAP value.
        """
        if self._shap_values is None:
            return {}
        mean_abs = np.abs(self._shap_values).mean(axis=0)
        return dict(zip(self.feat_names, mean_abs))

    def generate_safety_report(self, X_new: np.ndarray,
                               sample_labels: list = None) -> list:
        """Generate per-sample transformation risk reports.

        Args:
            X_new:         Feature matrix for new samples.
            sample_labels: Optional list of sample identifiers.

        Returns:
            List of report dictionaries.
        """
        risks = self.predict_risk(X_new)
        reports = []
        for i, risk in enumerate(risks):
            zone = ("RED"   if risk > 0.50 else
                    "AMBER" if risk > 0.15 else
                    "GREEN")
            lbl  = sample_labels[i] if sample_labels else f"Sample {i+1}"
            reports.append({
                "sample":              lbl,
                "transformation_prob": round(float(risk), 4),
                "risk_zone":           zone,
                "recommendation":      {
                    "RED":   "Halt: redesign vector or cell source",
                    "AMBER": "Enhanced monitoring + reduced dose",
                    "GREEN": "Proceed with standard monitoring",
                }[zone]
            })
        return reports


# ---------------------------------------------------------------------------
# Visualisation
# ---------------------------------------------------------------------------
def plot_module4_results(
    clf: TransformationSusceptibilityClassifier,
    X: np.ndarray,
    y: np.ndarray,
    feat_names: list,
    save_path: str = "outputs/M4_XGBoost_Results.png"
) -> None:
    """Generate the four-panel Module 4 results figure.

    Panels:
        A – ROC curve (5-fold CV)
        B – Global SHAP feature importance (horizontal bar chart)
        C – SHAP beeswarm-style summary
        D – Calibration curve

    Args:
        clf:        Fitted TransformationSusceptibilityClassifier.
        X:          Training feature matrix.
        y:          Training labels.
        feat_names: Feature name list.
        save_path:  Output PNG path.
    """
    fig = plt.figure(figsize=(17, 6), facecolor="white")
    gs  = gridspec.GridSpec(1, 4, wspace=0.42)

    # --- Panel A: ROC ---
    ax1 = fig.add_subplot(gs[0])
    fpr, tpr, _ = roc_curve(y, clf._y_prob_cv)
    auroc = clf.cv_metrics["AUROC"]
    ax1.plot(fpr, tpr, color="#1565C0", lw=2.5,
             label=f"XGBoost (AUROC={auroc:.3f})")
    ax1.fill_between(fpr, tpr, alpha=0.12, color="#1565C0")
    ax1.plot([0, 1], [0, 1], "k--", lw=1.2, alpha=0.5, label="Random")
    ax1.set_xlabel("False Positive Rate", fontsize=10, fontweight="bold")
    ax1.set_ylabel("True Positive Rate", fontsize=10, fontweight="bold")
    ax1.set_title(f"A.  ROC Curve (5-Fold CV)\n"
                  f"AUROC={auroc:.3f} | F1={clf.cv_metrics['F1']:.3f} | "
                  f"MCC={clf.cv_metrics['MCC']:.3f}",
                  fontsize=9, fontweight="bold")
    ax1.legend(fontsize=8.5)
    ax1.set_facecolor("#f8f9fa")

    # --- Panel B: Global SHAP importance ---
    ax2 = fig.add_subplot(gs[1])
    shap_global = clf.get_global_shap()
    sorted_feats = sorted(shap_global.items(), key=lambda x: x[1])
    names_sorted = [f[0] for f in sorted_feats]
    vals_sorted  = [f[1] for f in sorted_feats]
    total = sum(vals_sorted)
    y_pos = range(len(names_sorted))

    colors_bar = ["#1565C0" if v/total > 0.15 else "#00695C" if v/total > 0.08
                  else "#546E7A" for v in vals_sorted]
    bars = ax2.barh(y_pos, vals_sorted, color=colors_bar, edgecolor="white",
                    alpha=0.88, height=0.65)
    ax2.set_yticks(y_pos)
    ax2.set_yticklabels(names_sorted, fontsize=9)
    ax2.axvline(0, color="black", lw=0.6)
    for bar, val in zip(bars, vals_sorted):
        ax2.text(val + 0.002, bar.get_y() + bar.get_height()/2,
                 f"{val:.3f} ({val/total*100:.1f}%)",
                 va="center", fontsize=8, fontweight="bold")
    ax2.set_xlabel("Mean |SHAP Value|", fontsize=10, fontweight="bold")
    ax2.set_title("B.  Global SHAP Feature Importance\n(Mean |SHAP| — Training Set)",
                  fontsize=9, fontweight="bold")
    ax2.set_facecolor("#f8f9fa")

    # --- Panel C: SHAP per-feature distribution (violin proxy) ---
    ax3 = fig.add_subplot(gs[2])
    shap_vals = clf._shap_values
    sorted_idx = np.argsort([shap_global.get(fn, 0) for fn in feat_names])[::-1]

    for rank, fi in enumerate(sorted_idx):
        sv  = shap_vals[:, fi]
        fv  = X[:, fi]
        fv_norm = (fv - fv.min()) / (fv.max() - fv.min() + 1e-8)
        # jitter
        jitter = np.random.default_rng(fi).uniform(-0.25, 0.25, len(sv))
        sc = ax3.scatter(sv, rank + jitter, c=fv_norm, cmap="RdBu_r",
                         s=6, alpha=0.55, vmin=0, vmax=1)

    ax3.set_yticks(range(len(feat_names)))
    ax3.set_yticklabels([feat_names[fi] for fi in sorted_idx], fontsize=8.5)
    ax3.axvline(0, color="black", lw=1.2, alpha=0.6)
    ax3.set_xlabel("SHAP Value (impact on prediction)", fontsize=10, fontweight="bold")
    ax3.set_title("C.  SHAP Beeswarm Plot\n(Color = feature value: low=blue, high=red)",
                  fontsize=9, fontweight="bold")
    plt.colorbar(sc, ax=ax3, label="Feature value", fraction=0.03, pad=0.04)
    ax3.set_facecolor("#f8f9fa")

    # --- Panel D: Calibration curve ---
    ax4 = fig.add_subplot(gs[3])
    fraction_pos, mean_pred = calibration_curve(y, clf._y_prob_cv, n_bins=10)
    ax4.plot([0, 1], [0, 1], "k--", lw=1.2, alpha=0.5, label="Perfect calibration")
    ax4.plot(mean_pred, fraction_pos, color="#C62828", marker="o", lw=2.2,
             markersize=6, label="XGBoost (Platt)")
    ax4.fill_between(mean_pred, fraction_pos - 0.05, fraction_pos + 0.05,
                     alpha=0.12, color="#C62828")
    ax4.set_xlabel("Mean Predicted Probability", fontsize=10, fontweight="bold")
    ax4.set_ylabel("Fraction of Positives", fontsize=10, fontweight="bold")
    ax4.set_title("D.  Calibration Curve\n(Reliability Diagram)", fontsize=9, fontweight="bold")
    ax4.legend(fontsize=8.5)
    ax4.set_xlim(0, 1); ax4.set_ylim(0, 1)
    ax4.set_facecolor("#f8f9fa")

    fig.suptitle("Module 4: XGBoost Transformation Susceptibility Classifier "
                 "with SHAP Explainability",
                 fontsize=12, fontweight="bold", color="#1A237E", y=1.02)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"[M4] Figure saved → {save_path}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def run_module4(verbose: bool = True) -> dict:
    """Run the complete Module 4 pipeline.

    Returns:
        Dictionary of performance metrics and SHAP importances.
    """
    print("\n" + "="*60)
    print("  MODULE 4: XGBoost Transformation Susceptibility Classifier")
    print("="*60)

    # 1. Simulate data
    X, y, feat_names = simulate_transformation_dataset(n_samples=600, seed=42)

    # 2. Train
    clf = TransformationSusceptibilityClassifier(n_estimators=350,
                                                  max_depth=4,
                                                  learning_rate=0.04)
    clf.fit(X, y, feat_names=feat_names)

    if verbose:
        print("\n  5-Fold Cross-Validated Performance:")
        for k, v in clf.cv_metrics.items():
            print(f"    {k}: {v}")

        print("\n  Global SHAP Feature Importance:")
        shap_g = clf.get_global_shap()
        total  = sum(shap_g.values())
        for fn, sv in sorted(shap_g.items(), key=lambda x: -x[1]):
            print(f"    {fn:<38} {sv:.4f}  ({sv/total*100:.1f}%)")

        print("\n  Classification Report:")
        y_pred = (clf._y_prob_cv >= 0.50).astype(int)
        print(classification_report(y, y_pred,
                                    target_names=["No transform.", "Transform."]))

    # 3. Sample safety reports
    X_new = np.array([
        [0.07, 0.05, 1.00, 0.85, 0, 0.75],   # OT-I/NPM-ALK → RED
        [0.92, 0.45, 0.00, 0.60, 1, 0.10],   # WT polyclonal → GREEN
        [0.40, 0.20, 0.50, 0.70, 0, 0.40],   # intermediate  → AMBER
    ])
    labels = ["OT-I/NPM-ALK", "WT polyclonal", "Intermediate"]
    reports = clf.generate_safety_report(X_new, sample_labels=labels)

    if verbose:
        print("\n  Sample Safety Reports:")
        for r in reports:
            print(f"    [{r['risk_zone']}] {r['sample']}: "
                  f"risk={r['transformation_prob']:.3f}  "
                  f"→ {r['recommendation']}")

    # 4. Visualize
    plot_module4_results(clf, X, y, feat_names)

    return {"cv_metrics": clf.cv_metrics, "shap_importance": clf.get_global_shap()}


if __name__ == "__main__":
    run_module4(verbose=True)

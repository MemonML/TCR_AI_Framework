"""
module6_histopath/alcl_classifier.py
=====================================
Module 6: Vision Transformer-Based Automated ALCL Histopathology Classification.

Implements a patch-level morphological feature classifier that approximates
the ViT-based whole-slide image classification described in Manuscript Section 4.6.

Architecture:
    - Patch-level morphological feature extraction (12 features per patch)
    - Random Forest ensemble classifier (ViT-inspired multi-head attention analog)
    - Grad-CAM-inspired feature attribution per class
    - Slide-level prediction via majority vote aggregation

Classes:
    0 = ALCL (anaplastic large cell, NPM-ALK pattern)
    1 = Lymphoblastic lymphoma (ΔTrkA pattern)
    2 = Reactive/benign lymphoid tissue

Reference:
    Dosovitskiy A, et al. An image is worth 16x16 words. ICLR 2021.
    Chen RJ, et al. Towards a general-purpose foundation model for
    computational pathology. Nat Med. 2024;30(3):850-862.

Authors:
    Ashok Kumar¹, Mudasar Latif Memon*²
    CRAIMS, UMS, Tando Muhammad Khan, Sindh, Pakistan
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import (
    roc_auc_score, f1_score, matthews_corrcoef,
    classification_report, confusion_matrix
)
from sklearn.preprocessing import label_binarize

from utils.data_simulation import simulate_wsi_patches

CLASS_NAMES = ["ALCL\n(NPM-ALK)", "Lymphoblastic\n(ΔTrkA)", "Reactive\n(Benign)"]
CLASS_COLORS = ["#C62828", "#F57F17", "#2E7D32"]

FEATURE_NAMES = [
    "Nuclear area (mean)", "Nuclear area (std)", "Nuclear eccentricity",
    "N:C ratio", "Chromatin texture", "Mitotic index",
    "Sinusoidal infiltration", "Large cell fraction", "CD30 proxy",
    "Eosinophil density", "Lymphocyte density", "Necrosis fraction"
]


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------
class ALCLHistopathClassifier:
    """Random forest patch-level classifier for T-cell lymphoma subtyping.

    Approximates the ViT-based computational pathology model in Manuscript
    Section 4.6. Multi-head attention is approximated by the ensemble of
    decision trees, each attending to a different feature subset.

    Attributes:
        clf:          Trained RandomForestClassifier.
        cv_metrics:   Cross-validated performance.
        feat_importance: Per-feature importance (Gini-based).
    """

    def __init__(self, n_estimators: int = 400, max_depth: int = None,
                 seed: int = 42):
        self.clf = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            min_samples_leaf=3,
            max_features="sqrt",
            class_weight="balanced",
            random_state=seed,
            n_jobs=-1,
        )
        self.cv_metrics    = {}
        self.feat_importance = None

    def fit(self, X: np.ndarray, y: np.ndarray) -> "ALCLHistopathClassifier":
        """Train the patch-level classifier.

        Args:
            X: Patch feature matrix (n_patches × 12).
            y: Class labels (0, 1, or 2).

        Returns:
            self
        """
        self.clf.fit(X, y)
        self.feat_importance = self.clf.feature_importances_

        # Cross-validated performance
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        y_prob_cv = cross_val_predict(self.clf, X, y, cv=cv,
                                       method="predict_proba")
        y_pred_cv = y_prob_cv.argmax(axis=1)

        # OvR AUROC
        y_bin = label_binarize(y, classes=[0, 1, 2])
        auroc_ovr = roc_auc_score(y_bin, y_prob_cv, average="macro",
                                   multi_class="ovr")
        self.cv_metrics = {
            "AUROC (OvR macro)": round(auroc_ovr, 4),
            "F1 (macro)":        round(f1_score(y, y_pred_cv, average="macro"), 4),
            "F1 (weighted)":     round(f1_score(y, y_pred_cv, average="weighted"), 4),
            "MCC":               round(matthews_corrcoef(y, y_pred_cv), 4),
        }
        self._y_prob_cv = y_prob_cv
        self._y_pred_cv = y_pred_cv
        self._y         = y
        return self

    def predict_slide(self, patch_X: np.ndarray) -> dict:
        """Aggregate patch predictions to slide-level diagnosis.

        Uses majority vote + mean class probability to produce a slide-level
        diagnosis with confidence score.

        Args:
            patch_X: Patch feature matrix for a single slide (n_patches × 12).

        Returns:
            Dict: {predicted_class, class_name, confidence, probabilities}.
        """
        probs = self.clf.predict_proba(patch_X)   # (n_patches, 3)
        mean_prob = probs.mean(axis=0)             # slide-level aggregation
        pred_class = int(mean_prob.argmax())
        return {
            "predicted_class": pred_class,
            "class_name":      CLASS_NAMES[pred_class].replace("\n", " "),
            "confidence":      round(float(mean_prob[pred_class]), 4),
            "probabilities":   {CLASS_NAMES[i].replace("\n"," "): round(float(p), 4)
                                for i, p in enumerate(mean_prob)},
        }

    def grad_cam_attribution(self, X_patch: np.ndarray,
                              target_class: int = 0) -> np.ndarray:
        """Compute Grad-CAM-inspired feature attribution for a target class.

        Uses Gini-based feature importance weighted by class-conditional
        mean feature values — approximating saliency map generation.

        Args:
            X_patch:      Patch feature matrix.
            target_class: Target class for attribution (0=ALCL, 1=LBL, 2=Reactive).

        Returns:
            Feature attribution vector (length 12), normalized to [0, 1].
        """
        # Class-conditional mean feature values
        class_mask = self._y == target_class
        class_mean = X_patch[class_mask].mean(axis=0) if class_mask.any() else X_patch.mean(axis=0)
        other_mean = X_patch[~class_mask].mean(axis=0) if (~class_mask).any() else np.zeros(12)
        # Attribution = importance × class-discriminative signal
        discriminative = np.abs(class_mean - other_mean)
        attribution = self.feat_importance * discriminative
        attribution = attribution / (attribution.max() + 1e-8)
        return attribution


# ---------------------------------------------------------------------------
# Visualisation
# ---------------------------------------------------------------------------
def plot_module6_results(
    clf: ALCLHistopathClassifier,
    X: np.ndarray,
    y: np.ndarray,
    save_path: str = "outputs/M6_Histopath_Results.png"
) -> None:
    """Generate the four-panel Module 6 results figure.

    Panels:
        A – Confusion matrix (5-fold CV)
        B – Feature importance (Gini)
        C – Grad-CAM attribution per class
        D – Class probability distributions

    Args:
        clf:       Fitted ALCLHistopathClassifier.
        X:         Patch feature matrix.
        y:         Patch class labels.
        save_path: Output PNG path.
    """
    fig = plt.figure(figsize=(17, 5.5), facecolor="white")
    gs  = gridspec.GridSpec(1, 4, wspace=0.42)

    # --- Panel A: Confusion Matrix ---
    ax1 = fig.add_subplot(gs[0])
    cm  = confusion_matrix(y, clf._y_pred_cv, normalize="true")
    im  = ax1.imshow(cm, cmap="Blues", vmin=0, vmax=1)
    for i in range(3):
        for j in range(3):
            ax1.text(j, i, f"{cm[i,j]:.2f}", ha="center", va="center",
                     fontsize=11, fontweight="bold",
                     color="white" if cm[i,j] > 0.65 else "black")
    ax1.set_xticks([0, 1, 2])
    ax1.set_yticks([0, 1, 2])
    ax1.set_xticklabels(["ALCL", "Lymphobl.", "Reactive"], fontsize=9)
    ax1.set_yticklabels(["ALCL", "Lymphobl.", "Reactive"], fontsize=9)
    ax1.set_xlabel("Predicted", fontsize=10, fontweight="bold")
    ax1.set_ylabel("True", fontsize=10, fontweight="bold")
    ax1.set_title(f"A.  Confusion Matrix (Norm.)\n"
                  f"AUROC={clf.cv_metrics['AUROC (OvR macro)']:.3f}  "
                  f"F1={clf.cv_metrics['F1 (macro)']:.3f}",
                  fontsize=9, fontweight="bold")
    plt.colorbar(im, ax=ax1, fraction=0.04, pad=0.05)

    # --- Panel B: Gini Feature Importance ---
    ax2 = fig.add_subplot(gs[1])
    idx = np.argsort(clf.feat_importance)
    cols_imp = ["#C62828" if clf.feat_importance[i] > 0.10 else "#546E7A"
                for i in idx]
    ax2.barh(range(12), clf.feat_importance[idx], color=cols_imp,
             edgecolor="white", alpha=0.88)
    ax2.set_yticks(range(12))
    ax2.set_yticklabels([FEATURE_NAMES[i] for i in idx], fontsize=8.5)
    ax2.set_xlabel("Gini Importance", fontsize=10, fontweight="bold")
    ax2.set_title("B.  Feature Importance\n(Gini / Mean Decrease Impurity)",
                  fontsize=9, fontweight="bold")
    ax2.set_facecolor("#f8f9fa")

    # --- Panel C: Grad-CAM Attribution per class ---
    ax3 = fig.add_subplot(gs[2])
    for ci, (cname, ccol) in enumerate(zip(["ALCL", "Lymphobl.", "Reactive"], CLASS_COLORS)):
        attr = clf.grad_cam_attribution(X, target_class=ci)
        ax3.barh(
            np.arange(12) + ci * 0.28 - 0.28,
            attr,
            height=0.26,
            color=ccol, alpha=0.80, label=cname
        )
    ax3.set_yticks(range(12))
    ax3.set_yticklabels(FEATURE_NAMES, fontsize=8.5)
    ax3.set_xlabel("Grad-CAM Attribution Score", fontsize=10, fontweight="bold")
    ax3.set_title("C.  Grad-CAM Feature Attribution\n(Per Classification Class)",
                  fontsize=9, fontweight="bold")
    ax3.legend(fontsize=8.5)
    ax3.set_facecolor("#f8f9fa")

    # --- Panel D: Probability distributions per class ---
    ax4 = fig.add_subplot(gs[3])
    for ci, (cname, ccol) in enumerate(zip(CLASS_NAMES, CLASS_COLORS)):
        probs_ci = clf._y_prob_cv[clf._y == ci, ci]
        ax4.hist(probs_ci, bins=20, alpha=0.70, color=ccol,
                 density=True, label=cname.replace("\n"," "),
                 edgecolor="white")
    ax4.axvline(0.50, color="#1565C0", lw=1.8, ls="--",
                label="50% confidence")
    ax4.set_xlabel("Predicted Class Probability", fontsize=10, fontweight="bold")
    ax4.set_ylabel("Density", fontsize=10, fontweight="bold")
    ax4.set_title("D.  Predicted Prob. Distribution\n(True-Class Probabilities)",
                  fontsize=9, fontweight="bold")
    ax4.legend(fontsize=7.5)
    ax4.set_facecolor("#f8f9fa")

    fig.suptitle("Module 6: Automated ALCL Histopathology Classification "
                 "(ViT-Inspired Patch Classifier)",
                 fontsize=12, fontweight="bold", color="#1A237E", y=1.02)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"[M6] Figure saved → {save_path}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def run_module6(verbose: bool = True) -> dict:
    """Run the complete Module 6 pipeline."""
    print("\n" + "="*60)
    print("  MODULE 6: ALCL Histopathology Classifier (ViT-inspired)")
    print("="*60)

    X, y = simulate_wsi_patches(n_patches=1200, seed=42)
    clf  = ALCLHistopathClassifier(n_estimators=400)
    clf.fit(X, y)

    if verbose:
        print("\n  5-Fold CV Performance:")
        for k, v in clf.cv_metrics.items():
            print(f"    {k}: {v}")
        print("\n  Classification Report:")
        print(classification_report(y, clf._y_pred_cv,
                                    target_names=["ALCL","Lymphoblastic","Reactive"]))

    # Sample slide prediction
    alcl_patches = X[y == 0][:50]
    slide_result = clf.predict_slide(alcl_patches)
    if verbose:
        print(f"\n  Sample ALCL slide prediction:")
        print(f"    Predicted: {slide_result['class_name']}  "
              f"(confidence={slide_result['confidence']:.3f})")
        for cn, p in slide_result["probabilities"].items():
            print(f"      {cn}: {p:.4f}")

    plot_module6_results(clf, X, y)
    return {"cv_metrics": clf.cv_metrics}


if __name__ == "__main__":
    run_module6(verbose=True)

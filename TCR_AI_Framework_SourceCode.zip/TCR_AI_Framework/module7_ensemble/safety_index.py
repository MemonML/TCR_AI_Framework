"""
module7_ensemble/safety_index.py
==================================
Module 7: Multi-Modal Ensemble Gene Therapy Safety Index.

Aggregates outputs from Modules 1–6 into a unified Gene Therapy Safety Index
using a stacking ensemble meta-learner, producing RED / AMBER / GREEN
traffic-light safety classification with SHAP explainability.

Safety Index formula (linear combination for transparency):
    S = 1 − [w₁·(1−PI) + w₂·oncogene_str + w₃·IS_risk
              + w₄·transf_prob + w₅·phenotype + w₆·niche_var]

    where w = (0.40, 0.28, 0.15, 0.10, 0.04, 0.03)  (calibrated weights)

Classification thresholds (Module 7 output, Manuscript Section 4.7):
    GREEN : S > 0.60  (PI > 0.80; IS risk < 0.20; transf_prob < 0.15)
    AMBER : 0.35 ≤ S ≤ 0.60  (enhanced monitoring recommended)
    RED   : S < 0.35  (PI < 0.30; transf_prob > 0.50 — halt/redesign)

Reference:
    Newrzela S, et al. Leukemia. 2012;26(12):2456-2464.
    Lundberg SM, Lee SI. NeurIPS 2017;30:4765-4774.

Authors:
    Ashok Kumar¹, Mudasar Latif Memon*²
    CRAIMS, UMS, Tando Muhammad Khan, Sindh, Pakistan
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
import warnings
warnings.filterwarnings("ignore")

import xgboost as xgb
import shap
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import (
    roc_auc_score, f1_score, matthews_corrcoef,
    brier_score_loss, classification_report, roc_curve
)
from sklearn.calibration import CalibratedClassifierCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from utils.data_simulation import simulate_transformation_dataset


# ---------------------------------------------------------------------------
# Safety Index Weights (calibrated to experimental data, Manuscript §4.7)
# ---------------------------------------------------------------------------
SAFETY_WEIGHTS = np.array([0.40, 0.28, 0.15, 0.10, 0.04, 0.03])
GREEN_THRESHOLD = 0.60
RED_THRESHOLD   = 0.35

FEATURE_NAMES = [
    "Polyclonality Index (PI)",
    "Oncogene Strength",
    "Integration Site Risk",
    "Transformation Probability",
    "T-cell Phenotype",
    "Niche Affinity Variance",
]


# ---------------------------------------------------------------------------
# Safety Index Calculator
# ---------------------------------------------------------------------------
def compute_safety_score(module_outputs: np.ndarray) -> np.ndarray:
    """Compute the linear Gene Therapy Safety Score.

    Safety Score S = 1 − [w · (1−PI, oncogene, IS_risk,
                                 transf_prob, phenotype, niche_var)]

    Args:
        module_outputs: Matrix of shape (n_samples × 6) where columns are:
            [PI, oncogene_strength, IS_risk,
             transf_prob, phenotype, niche_affinity_var]

    Returns:
        Safety scores ∈ [0, 1] (higher = safer).
    """
    pi     = module_outputs[:, 0]
    onco   = module_outputs[:, 1]
    is_r   = module_outputs[:, 2]
    tp     = module_outputs[:, 3]
    phen   = module_outputs[:, 4] / max(module_outputs[:, 4].max(), 1)
    nav    = module_outputs[:, 5]

    risk_composite = (SAFETY_WEIGHTS[0] * (1 - pi)
                      + SAFETY_WEIGHTS[1] * onco
                      + SAFETY_WEIGHTS[2] * is_r
                      + SAFETY_WEIGHTS[3] * tp
                      + SAFETY_WEIGHTS[4] * phen
                      + SAFETY_WEIGHTS[5] * nav)
    return np.clip(1.0 - risk_composite, 0.0, 1.0)


def classify_safety(safety_scores: np.ndarray) -> list:
    """Convert safety scores to RED / AMBER / GREEN zones.

    Args:
        safety_scores: Array of safety scores ∈ [0, 1].

    Returns:
        List of zone strings.
    """
    zones = []
    for s in safety_scores:
        if   s >= GREEN_THRESHOLD: zones.append("GREEN")
        elif s >= RED_THRESHOLD:   zones.append("AMBER")
        else:                      zones.append("RED")
    return zones


# ---------------------------------------------------------------------------
# Ensemble Safety Index (XGBoost meta-learner + SHAP)
# ---------------------------------------------------------------------------
class GenetherapySafetyIndex:
    """Multi-modal ensemble Gene Therapy Safety Index.

    Combines the linear safety score with a calibrated XGBoost meta-learner
    to produce probability-calibrated RED/AMBER/GREEN classifications with
    SHAP feature attribution.

    Attributes:
        meta_model:      Calibrated XGBoost meta-learner.
        shap_explainer:  TreeExplainer for global attribution.
        cv_metrics:      Cross-validated performance.
    """

    def __init__(self, seed: int = 42):
        base = xgb.XGBClassifier(
            n_estimators=300,
            max_depth=4,
            learning_rate=0.04,
            subsample=0.8,
            colsample_bytree=0.8,
            use_label_encoder=False,
            eval_metric="logloss",
            random_state=seed,
            verbosity=0,
        )
        self.meta_model    = CalibratedClassifierCV(base, cv=5, method="isotonic")
        self.shap_explainer = None
        self.cv_metrics    = {}
        self._base_xgb     = base
        self._seed         = seed

    def fit(self, X: np.ndarray, y: np.ndarray) -> "GenetherapySafetyIndex":
        """Train the ensemble safety index on module-aggregated features.

        Args:
            X: Module output feature matrix (n_samples × 6).
            y: Binary safety labels (0 = lymphoma/unsafe, 1 = healthy/safe).

        Returns:
            self
        """
        # Add computed safety score as an extra feature
        safety_scores = compute_safety_score(X)
        X_aug = np.column_stack([X, safety_scores])

        self.meta_model.fit(X_aug, y)
        # Fit base model for SHAP
        self._base_xgb.fit(X_aug, y)
        self.shap_explainer = shap.TreeExplainer(self._base_xgb)
        self._shap_vals     = self.shap_explainer.shap_values(X_aug)
        self._X_aug         = X_aug

        # CV metrics
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=self._seed)
        y_prob_cv = cross_val_predict(
            self.meta_model, X_aug, y, cv=cv, method="predict_proba"
        )[:, 1]
        y_pred_cv = (y_prob_cv >= 0.50).astype(int)

        self.cv_metrics = {
            "AUROC":       round(roc_auc_score(y, y_prob_cv), 4),
            "F1":          round(f1_score(y, y_pred_cv), 4),
            "MCC":         round(matthews_corrcoef(y, y_pred_cv), 4),
            "Brier Score": round(brier_score_loss(y, y_prob_cv), 4),
        }
        self._y_prob_cv = y_prob_cv
        self._y_pred_cv = y_pred_cv
        self._y         = y
        return self

    def predict_safety(self, X: np.ndarray) -> dict:
        """Predict gene therapy safety for new samples.

        Args:
            X: Module output feature matrix (n_samples × 6).

        Returns:
            Dict with safety_scores, safety_probs, zones, and SHAP values.
        """
        safety_scores = compute_safety_score(X)
        X_aug = np.column_stack([X, safety_scores])
        probs = self.meta_model.predict_proba(X_aug)[:, 1]
        zones = classify_safety(safety_scores)
        return {
            "safety_scores": safety_scores,
            "safe_probs":    probs,
            "zones":         zones,
        }

    def generate_regulatory_report(
        self,
        X: np.ndarray,
        sample_ids: list = None
    ) -> list:
        """Generate a regulatory-grade safety report per sample.

        Args:
            X:          Module output feature matrix.
            sample_ids: Optional sample identifiers.

        Returns:
            List of per-sample report dictionaries.
        """
        pred = self.predict_safety(X)
        reports = []
        feat_names_aug = FEATURE_NAMES + ["Composite Safety Score"]
        shap_new = self.shap_explainer.shap_values(np.column_stack([X, pred["safety_scores"]]))

        for i in range(len(X)):
            zone = pred["zones"][i]
            shap_i = shap_new[i]
            # Top 3 contributing features
            top3_idx = np.argsort(np.abs(shap_i))[::-1][:3]
            top3 = [(feat_names_aug[j], round(float(shap_i[j]), 4)) for j in top3_idx]

            reports.append({
                "sample_id":       sample_ids[i] if sample_ids else f"S{i+1:03d}",
                "safety_score":    round(float(pred["safety_scores"][i]), 4),
                "safe_probability":round(float(pred["safe_probs"][i]), 4),
                "zone":            zone,
                "recommendation": {
                    "GREEN": "Proceed with standard monitoring",
                    "AMBER": "Enhanced monitoring + consider polyclonality augmentation",
                    "RED":   "HALT — vector redesign or alternative cell source required",
                }[zone],
                "key_risk_drivers": top3,
            })
        return reports

    def global_shap_summary(self) -> dict:
        """Return global mean |SHAP| per feature.

        Returns:
            Dict mapping feature name → mean absolute SHAP value.
        """
        feat_names_aug = FEATURE_NAMES + ["Composite Safety Score"]
        mean_abs = np.abs(self._shap_vals).mean(axis=0)
        return dict(zip(feat_names_aug, mean_abs))


# ---------------------------------------------------------------------------
# Visualisation
# ---------------------------------------------------------------------------
def plot_module7_results(
    gsi: GenetherapySafetyIndex,
    X: np.ndarray,
    y: np.ndarray,
    save_path: str = "outputs/M7_SafetyIndex_Results.png"
) -> None:
    """Generate the four-panel Module 7 results figure.

    Panels:
        A – Safety score distribution by outcome (RED/AMBER/GREEN zones)
        B – ROC curve
        C – SHAP global feature attribution
        D – Regulatory traffic light summary

    Args:
        gsi:       Fitted GenetherapySafetyIndex.
        X:         Feature matrix.
        y:         Labels.
        save_path: Output PNG path.
    """
    safety_scores = compute_safety_score(X)
    zones         = classify_safety(safety_scores)

    fig = plt.figure(figsize=(17, 5.5), facecolor="white")
    gs  = gridspec.GridSpec(1, 4, wspace=0.42)

    # --- Panel A: Safety score by outcome ---
    ax1 = fig.add_subplot(gs[0])
    ax1.set_facecolor("#f8f9fa")
    ax1.hist(safety_scores[y == 0], bins=25, alpha=0.72, color="#C62828",
             density=True, label="Lymphoma/Unsafe", edgecolor="white")
    ax1.hist(safety_scores[y == 1], bins=25, alpha=0.72, color="#2E7D32",
             density=True, label="Healthy/Safe",   edgecolor="white")
    ax1.axvline(GREEN_THRESHOLD, color="#2E7D32", lw=2, ls=":",
                label=f"GREEN ≥{GREEN_THRESHOLD}")
    ax1.axvline(RED_THRESHOLD,   color="#C62828", lw=2, ls="--",
                label=f"RED <{RED_THRESHOLD}")
    ax1.axvspan(0,             RED_THRESHOLD,   alpha=0.07, color="red")
    ax1.axvspan(RED_THRESHOLD, GREEN_THRESHOLD, alpha=0.05, color="orange")
    ax1.axvspan(GREEN_THRESHOLD, 1.0,           alpha=0.07, color="green")
    y_top = ax1.get_ylim()[1]
    ax1.text(0.17, y_top*0.90, "RED",   ha="center", fontsize=9, fontweight="bold", color="#C62828")
    ax1.text(0.48, y_top*0.90, "AMBER", ha="center", fontsize=9, fontweight="bold", color="#E65100")
    ax1.text(0.80, y_top*0.90, "GREEN", ha="center", fontsize=9, fontweight="bold", color="#2E7D32")
    ax1.set_xlabel("Gene Therapy Safety Score", fontsize=10, fontweight="bold")
    ax1.set_ylabel("Density",                   fontsize=10, fontweight="bold")
    ax1.set_title("A.  Safety Score Distribution\nby Clinical Outcome", fontsize=9, fontweight="bold")
    ax1.legend(fontsize=7.5)
    ax1.set_xlim(0, 1)

    # --- Panel B: ROC curve ---
    ax2 = fig.add_subplot(gs[1])
    ax2.set_facecolor("#f8f9fa")
    fpr, tpr, _ = roc_curve(y, gsi._y_prob_cv)
    auroc = gsi.cv_metrics["AUROC"]
    ax2.plot(fpr, tpr, color="#1A237E", lw=2.5,
             label=f"Ensemble (AUROC={auroc:.3f})")
    ax2.fill_between(fpr, tpr, alpha=0.12, color="#1A237E")
    ax2.plot([0, 1], [0, 1], "k--", lw=1.2, alpha=0.5, label="Random")
    ax2.set_xlabel("False Positive Rate", fontsize=10, fontweight="bold")
    ax2.set_ylabel("True Positive Rate",  fontsize=10, fontweight="bold")
    ax2.set_title(f"B.  ROC Curve (5-Fold CV)\n"
                  f"AUROC={auroc:.3f} | F1={gsi.cv_metrics['F1']:.3f} | "
                  f"MCC={gsi.cv_metrics['MCC']:.3f}",
                  fontsize=9, fontweight="bold")
    ax2.legend(fontsize=9)

    # --- Panel C: SHAP bar chart ---
    ax3 = fig.add_subplot(gs[2])
    ax3.set_facecolor("#f8f9fa")
    shap_g  = gsi.global_shap_summary()
    sorted_items = sorted(shap_g.items(), key=lambda x: x[1])
    names   = [i[0] for i in sorted_items]
    vals    = [i[1] for i in sorted_items]
    total   = sum(vals)
    colors  = ["#1A237E" if v/total > 0.15 else "#1565C0" if v/total > 0.08
               else "#546E7A" for v in vals]
    bars = ax3.barh(range(len(names)), vals, color=colors,
                    edgecolor="white", alpha=0.88, height=0.62)
    ax3.set_yticks(range(len(names)))
    ax3.set_yticklabels(names, fontsize=8.5)
    for bar, val in zip(bars, vals):
        ax3.text(val + 0.002, bar.get_y() + bar.get_height()/2,
                 f"{val:.3f} ({val/total*100:.1f}%)",
                 va="center", fontsize=8, fontweight="bold")
    ax3.set_xlabel("Mean |SHAP Value|", fontsize=10, fontweight="bold")
    ax3.set_title("C.  SHAP Feature Attribution\n(Module 7 Ensemble — Global)",
                  fontsize=9, fontweight="bold")
    ax3.set_xlim(0, max(vals) * 1.35)

    # --- Panel D: Traffic-light summary per condition ---
    ax4 = fig.add_subplot(gs[3])
    ax4.set_facecolor("white")
    ax4.axis("off")

    # Experimental conditions
    conditions = [
        # (label, PI, onco, IS_risk, transf, phen, nav)
        ("OT-I / NPM-ALK\n(monoclonal)",  [0.07, 1.0, 0.78, 0.98, 0, 0.05]),
        ("OT-I / ΔTrkA\n(monoclonal)",    [0.07, 0.5, 0.65, 0.70, 0, 0.05]),
        ("WT polyclonal + NPM-ALK\n(co-tx)",[0.90, 1.0, 0.70, 0.05, 0, 0.45]),
        ("WT polyclonal\n(healthy)",       [0.93, 0.0, 0.12, 0.02, 0, 0.48]),
        ("CAR-T (oligoclonal)\n[warning]", [0.35, 0.8, 0.55, 0.48, 1, 0.15]),
    ]
    zone_col = {"RED": "#C62828", "AMBER": "#E65100", "GREEN": "#2E7D32"}
    zone_bg  = {"RED": "#FFEBEE", "AMBER": "#FFF3E0", "GREEN": "#E8F5E9"}

    ax4.set_xlim(0, 1)
    ax4.set_ylim(-0.05, len(conditions) + 0.5)

    ax4.text(0.5, len(conditions) + 0.3, "D.  Regulatory Safety Classification",
             ha="center", va="center", fontsize=9, fontweight="bold",
             color="#1A237E", transform=ax4.transData)

    for row, (label, feat) in enumerate(reversed(conditions)):
        X_cond = np.array([feat])
        result = gsi.predict_safety(X_cond)
        zone   = result["zones"][0]
        score  = result["safety_scores"][0]
        y_row  = row

        # Background rectangle
        rect = mpatches.FancyBboxPatch((0.02, y_row - 0.4), 0.96, 0.78,
                                        boxstyle="round,pad=0.03",
                                        facecolor=zone_bg[zone], edgecolor=zone_col[zone],
                                        linewidth=1.5)
        ax4.add_patch(rect)

        # Zone indicator circle
        circle = plt.Circle((0.09, y_row), 0.08, color=zone_col[zone], zorder=5)
        ax4.add_patch(circle)
        ax4.text(0.09, y_row, zone[0], ha="center", va="center",
                 fontsize=8, fontweight="bold", color="white", zorder=6)

        # Label and score
        ax4.text(0.20, y_row + 0.10, label, va="center", ha="left",
                 fontsize=7.5, fontweight="bold", color="#1A237E")
        ax4.text(0.20, y_row - 0.12, f"S = {score:.2f}",
                 va="center", ha="left", fontsize=7, color=zone_col[zone],
                 fontweight="bold")

    fig.suptitle(
        "Module 7: Multi-Modal Ensemble Gene Therapy Safety Index — "
        "RED / AMBER / GREEN Surveillance",
        fontsize=12, fontweight="bold", color="#1A237E", y=1.02
    )
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"[M7] Figure saved → {save_path}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
def run_module7(verbose: bool = True) -> dict:
    """Run the complete Module 7 pipeline."""
    print("\n" + "="*60)
    print("  MODULE 7: Multi-Modal Ensemble Gene Therapy Safety Index")
    print("="*60)

    # Simulate module output data
    X_raw, y, _ = simulate_transformation_dataset(n_samples=600, seed=42)
    # Reorder to match module output schema: [PI, onco, IS_risk, transf, phen, nav]
    X = np.column_stack([
        X_raw[:, 0],  # PI
        X_raw[:, 2],  # oncogene strength
        X_raw[:, 5],  # integration site risk
        1 - X_raw[:, 0] * 0.8,  # transformation prob (proxy)
        X_raw[:, 4],  # T-cell phenotype
        X_raw[:, 1],  # niche affinity variance
    ])
    y_safe = 1 - y  # 1 = safe (no lymphoma)

    # Train
    gsi = GenetherapySafetyIndex(seed=42)
    gsi.fit(X, y_safe)

    if verbose:
        print("\n  5-Fold CV Performance:")
        for k, v in gsi.cv_metrics.items():
            print(f"    {k}: {v}")

        print("\n  Global SHAP Attribution:")
        shap_g = gsi.global_shap_summary()
        total  = sum(shap_g.values())
        for fn, sv in sorted(shap_g.items(), key=lambda x: -x[1]):
            print(f"    {fn:<38} {sv:.4f}  ({sv/total*100:.1f}%)")

    # Regulatory reports for landmark conditions
    X_landmark = np.array([
        [0.07, 1.00, 0.78, 0.98, 0, 0.05],  # OT-I/NPM-ALK → RED
        [0.07, 0.50, 0.65, 0.70, 0, 0.05],  # OT-I/ΔTrkA   → RED/AMBER
        [0.90, 1.00, 0.70, 0.05, 0, 0.45],  # WT co-tx      → GREEN
        [0.93, 0.00, 0.12, 0.02, 0, 0.48],  # WT polyclonal → GREEN
        [0.35, 0.80, 0.55, 0.48, 1, 0.15],  # CAR-T oligo   → AMBER
    ])
    labels = ["OT-I/NPM-ALK", "OT-I/ΔTrkA", "WT co-transplant",
              "WT polyclonal", "CAR-T (oligoclonal)"]
    reports = gsi.generate_regulatory_report(X_landmark, sample_ids=labels)

    if verbose:
        print("\n  Regulatory Safety Reports:")
        print(f"  {'Sample':<22} {'Score':>6} {'Zone':>6}  Recommendation")
        print("  " + "-"*72)
        for r in reports:
            print(f"  {r['sample_id']:<22} {r['safety_score']:>6.3f} "
                  f"{r['zone']:>6}  {r['recommendation'][:45]}")

    plot_module7_results(gsi, X, y_safe)
    return {"cv_metrics": gsi.cv_metrics, "reports": reports}


if __name__ == "__main__":
    run_module7(verbose=True)

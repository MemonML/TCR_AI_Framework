"""
utils/data_simulation.py
========================
Shared data simulation utilities for the TCR AI Framework.

Generates biologically realistic synthetic data for all seven modules,
calibrated to the experimental findings of Newrzela et al. (Leukemia, 2012).

Reference:
    Newrzela S, et al. T-cell receptor diversity prevents T-cell lymphoma
    development. Leukemia. 2012;26(12):2456-2464.
"""

import numpy as np
from typing import Tuple, List, Dict
import warnings
warnings.filterwarnings("ignore")


# ---------------------------------------------------------------------------
# Constants calibrated to Newrzela et al. [1]
# ---------------------------------------------------------------------------
AMINO_ACIDS = list("ACDEFGHIKLMNPQRSTVWY")
CDR3_MIN_LEN, CDR3_MAX_LEN = 8, 18
N_HLA_ALLELES = 6       # HLA-A, B, C alleles represented
LYMPHOMA_LATENCY_NPM_ALK_MONO = 55.0   # median days, monoclonal
LYMPHOMA_LATENCY_DTRKA_MONO   = 130.0  # median days, monoclonal
LYMPHOMA_LATENCY_WT_POLY      = 195.0  # median days (2/6 mice only)
PI_MONOCLONAL = 0.07    # PI for OT-I / P14 TCR transgenic
PI_POLYCLONAL = 0.92    # PI for WT polyclonal
RNG = np.random.default_rng(42)


# ---------------------------------------------------------------------------
# Module 1 – TCR Diversity Data
# ---------------------------------------------------------------------------
def simulate_tcr_repertoire(
    n_clones: int = 500,
    condition: str = "polyclonal",
    seed: int = 42
) -> Tuple[np.ndarray, np.ndarray]:
    """Simulate a TCR repertoire as CDR3 sequences with clone frequencies.

    Args:
        n_clones: Number of unique clonotypes to generate.
        condition: One of {'polyclonal', 'monoclonal', 'cancer'}.
            'polyclonal'  – uniform-ish Dirichlet distribution (high PI).
            'monoclonal'  – one dominant clone (low PI).
            'cancer'      – oligoclonal (intermediate PI).
        seed: Random seed for reproducibility.

    Returns:
        cdr3_seqs  : Array of CDR3 amino acid sequences (shape [n_clones]).
        frequencies: Normalized clone frequency array (shape [n_clones]).
    """
    rng = np.random.default_rng(seed)

    # Generate random CDR3 sequences
    cdr3_seqs = []
    for _ in range(n_clones):
        length = rng.integers(CDR3_MIN_LEN, CDR3_MAX_LEN + 1)
        seq = "".join(rng.choice(AMINO_ACIDS, size=length))
        cdr3_seqs.append(seq)

    # Clone frequency distribution by condition
    alpha_map = {"polyclonal": 5.0, "monoclonal": 0.05, "cancer": 0.4}
    alpha = alpha_map.get(condition, 1.0)
    raw = rng.dirichlet(np.full(n_clones, alpha))
    frequencies = raw / raw.sum()

    return np.array(cdr3_seqs), frequencies


def simulate_tcr_dataset(
    n_samples: int = 300,
    seed: int = 42
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Simulate a labelled TCR repertoire dataset for classifier training.

    Each sample is a flattened feature vector encoding:
        - Shannon entropy (1 feature)
        - Gini coefficient (1 feature)
        - Top-clone dominance (1 feature)
        - V-gene usage entropy (1 feature)
        - Clone count (1 feature)
        Total: 5 repertoire-level features

    Args:
        n_samples: Number of repertoire samples.
        seed: Random seed.

    Returns:
        X    : Feature matrix (n_samples × 5).
        y    : Binary lymphoma labels (0 = healthy, 1 = lymphoma).
        pi   : Polyclonality Index array (n_samples,).
    """
    rng = np.random.default_rng(seed)
    X, y, pi_list = [], [], []

    for i in range(n_samples):
        # Randomly assign condition
        cond = rng.choice(["polyclonal", "monoclonal", "cancer"],
                          p=[0.45, 0.30, 0.25])
        _, freq = simulate_tcr_repertoire(
            n_clones=rng.integers(100, 800), condition=cond, seed=int(rng.integers(1e6))
        )
        # Compute features
        H = _shannon_entropy(freq)
        H_max = np.log2(len(freq)) if len(freq) > 1 else 1.0
        polyclonality = H / H_max if H_max > 0 else 0.0
        gini = _gini(freq)
        top_dom = freq.max()
        v_entropy = rng.uniform(0.3, 0.9) if cond == "polyclonal" else rng.uniform(0.1, 0.5)
        n_clones = len(freq)

        X.append([polyclonality, gini, top_dom, v_entropy, np.log1p(n_clones)])
        pi_list.append(polyclonality)

        # Label: lymphoma risk inversely proportional to PI
        risk_prob = 1.0 / (1.0 + np.exp(8 * (polyclonality - 0.45)))
        label = int(rng.uniform() < risk_prob)
        y.append(label)

    return np.array(X), np.array(y), np.array(pi_list)


# ---------------------------------------------------------------------------
# Module 4 – Transformation Susceptibility Data
# ---------------------------------------------------------------------------
def simulate_transformation_dataset(
    n_samples: int = 400,
    seed: int = 42
) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """Simulate pre-transplant features for transformation susceptibility.

    Feature columns:
        [0] polyclonality_index   – PI ∈ [0,1]
        [1] niche_affinity_var    – σ²(A_i) ∈ [0,1]
        [2] oncogene_strength     – 0=control, 0.5=ΔTrkA, 1.0=NPM-ALK
        [3] transduction_effic    – %GFP+ ∈ [0,1]
        [4] tcell_phenotype       – 0=naive, 1=memory
        [5] integration_site_risk – ∈ [0,1]

    Returns:
        X       : Feature matrix (n_samples × 6).
        y       : Binary transformation labels.
        feat_names: List of feature names.
    """
    rng = np.random.default_rng(seed)
    feat_names = [
        "Polyclonality Index (PI)",
        "Niche Affinity Variance",
        "Oncogene Strength",
        "Transduction Efficiency",
        "T-cell Phenotype (0=naive)",
        "Integration Site Risk"
    ]
    X, y = [], []
    for _ in range(n_samples):
        pi   = rng.beta(3, 1) if rng.uniform() > 0.4 else rng.beta(1, 10)
        nav  = rng.uniform(0, 1 - pi)  # low pi → low niche variance
        onco = rng.choice([0.0, 0.5, 1.0], p=[0.25, 0.35, 0.40])
        teff = rng.uniform(0.3, 0.95)
        phen = int(rng.uniform() > 0.5)
        isr  = rng.beta(2, 5)

        risk = (0.40 * (1 - pi) + 0.28 * onco + 0.15 * isr
                + 0.07 * teff + 0.05 * phen + 0.05 * nav)
        label = int(rng.uniform() < np.clip(risk, 0, 1))
        X.append([pi, nav, onco, teff, phen, isr])
        y.append(label)

    return np.array(X), np.array(y), feat_names


# ---------------------------------------------------------------------------
# Module 5 – Integration Site Data
# ---------------------------------------------------------------------------
def simulate_integration_sites(
    n_sites: int = 131,
    n_tumors: int = 31,
    seed: int = 42
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Simulate retroviral integration site data mirroring Newrzela et al.

    Creates 131 integration sites across 31 tumors, with biologically
    realistic CIS clusters near LMO2, PIM1, and Dnalc4 loci.

    Returns:
        X        : Feature matrix – each row = [dist_tss_kb, chromatin_acc,
                   h3k4me3, gene_density, rtcgd_proximity] (n_sites × 5).
        y        : High-risk labels (1 = near known cancer driver).
        tumor_ids: Tumor assignment for each site (n_sites,).
    """
    rng = np.random.default_rng(seed)
    sites = []
    labels = []
    tumor_ids = []

    # CIS loci: (dist_tss_kb, chromatin, h3k4, gene_density, rtcgd)
    cis_params = {
        "LMO2":   (12, 0.91, 0.88, 0.90, 0.95),
        "PIM1":   (20, 0.84, 0.81, 0.82, 0.88),
        "Dnalc4": (7,  0.94, 0.90, 0.87, 0.72),
    }

    # First assign known CIS sites
    cis_assignments = ["LMO2"] * 4 + ["PIM1"] * 3 + ["Dnalc4"] * 5
    for cis in cis_assignments:
        p = cis_params[cis]
        site = [
            max(0, rng.normal(p[0], 3)),
            np.clip(rng.normal(p[1], 0.05), 0, 1),
            np.clip(rng.normal(p[2], 0.06), 0, 1),
            np.clip(rng.normal(p[3], 0.06), 0, 1),
            np.clip(rng.normal(p[4], 0.04), 0, 1),
        ]
        sites.append(site)
        labels.append(1)
        tumor_ids.append(rng.integers(0, n_tumors))

    # Background sites
    for _ in range(n_sites - len(cis_assignments)):
        site = [
            rng.exponential(100),             # dist TSS
            rng.beta(2, 3),                   # chromatin
            rng.beta(1.5, 3),                 # H3K4me3
            rng.beta(2, 4),                   # gene density
            rng.beta(1, 5),                   # RTCGD proximity
        ]
        risk = 0.4 * site[1] + 0.3 * site[4] + 0.3 * np.exp(-site[0] / 50)
        sites.append(site)
        labels.append(int(rng.uniform() < risk * 0.25))
        tumor_ids.append(rng.integers(0, n_tumors))

    return (np.array(sites, dtype=np.float32),
            np.array(labels),
            np.array(tumor_ids))


# ---------------------------------------------------------------------------
# Module 6 – Histopathology Data
# ---------------------------------------------------------------------------
def simulate_wsi_patches(
    n_patches: int = 1200,
    seed: int = 42
) -> Tuple[np.ndarray, np.ndarray]:
    """Simulate morphological patch-level features from H&E whole-slide images.

    Each patch is encoded by 12 morphological features derived from nuclear
    segmentation analysis, mimicking standard computational pathology pipelines.

    Features (per patch):
        nuclear_area_mean, nuclear_area_std, nuclear_eccentricity,
        n2c_ratio, chromatin_texture, mitotic_index, sinusoidal_infiltration,
        large_cell_fraction, cd30_proxy, eosinophil_density,
        lymphocyte_density, necrosis_fraction

    Classes:
        0 = ALCL (anaplastic large cell, NPM-ALK pattern)
        1 = Lymphoblastic lymphoma (ΔTrkA pattern)
        2 = Reactive/benign lymphoid tissue

    Returns:
        X: Patch feature matrix (n_patches × 12).
        y: Class labels (n_patches,).
    """
    rng = np.random.default_rng(seed)
    class_probs = [0.40, 0.30, 0.30]
    labels = rng.choice([0, 1, 2], size=n_patches, p=class_probs)

    feat_params = {
        # (mean_by_class[3], std)
        "nuclear_area_mean":       ([180, 95, 75],   15),
        "nuclear_area_std":        ([60, 25, 18],    10),
        "nuclear_eccentricity":    ([0.72, 0.55, 0.42], 0.08),
        "n2c_ratio":               ([0.65, 0.80, 0.45], 0.07),
        "chromatin_texture":       ([0.70, 0.60, 0.35], 0.09),
        "mitotic_index":           ([0.18, 0.25, 0.04], 0.05),
        "sinusoidal_infiltration": ([0.60, 0.20, 0.10], 0.08),
        "large_cell_fraction":     ([0.55, 0.15, 0.10], 0.08),
        "cd30_proxy":              ([0.80, 0.10, 0.05], 0.07),
        "eosinophil_density":      ([0.25, 0.08, 0.12], 0.05),
        "lymphocyte_density":      ([0.40, 0.65, 0.72], 0.08),
        "necrosis_fraction":       ([0.12, 0.08, 0.02], 0.04),
    }

    X = np.zeros((n_patches, len(feat_params)))
    for j, (_, (means, std)) in enumerate(feat_params.items()):
        for i, lbl in enumerate(labels):
            X[i, j] = np.clip(rng.normal(means[lbl], std), 0, None)

    # Normalize to [0,1]
    X_min, X_max = X.min(axis=0), X.max(axis=0)
    X = (X - X_min) / (X_max - X_min + 1e-8)
    return X, labels


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------
def _shannon_entropy(freq: np.ndarray) -> float:
    """Compute Shannon entropy H = -∑ p_i log₂(p_i)."""
    freq = freq[freq > 0]
    return float(-np.sum(freq * np.log2(freq + 1e-12)))


def _gini(freq: np.ndarray) -> float:
    """Compute Gini coefficient (0 = equal, 1 = maximally unequal)."""
    freq = np.sort(freq)
    n = len(freq)
    cumsum = np.cumsum(freq)
    return float((2 * np.sum(cumsum) - (n + 1) * freq.sum()) / (n * freq.sum() + 1e-12))


def compute_polyclonality_index(frequencies: np.ndarray) -> float:
    """Compute Polyclonality Index (PI) = H / log₂(N).

    PI = 0 → complete monoclonality.
    PI = 1 → maximum Shannon diversity.

    Args:
        frequencies: Clone frequency array (must sum to 1).

    Returns:
        PI value in [0, 1].
    """
    n = len(frequencies)
    if n <= 1:
        return 0.0
    H = _shannon_entropy(frequencies)
    H_max = np.log2(n)
    return float(H / H_max) if H_max > 0 else 0.0
